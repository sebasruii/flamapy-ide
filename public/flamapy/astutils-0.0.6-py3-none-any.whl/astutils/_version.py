# This file was generated from setup.py
version = '0.0.6'
