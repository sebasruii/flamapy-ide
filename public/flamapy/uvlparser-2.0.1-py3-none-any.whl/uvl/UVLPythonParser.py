# Generated from uvl/UVLPython.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,63,409,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,1,0,
        3,0,68,8,0,1,0,3,0,71,8,0,1,0,3,0,74,8,0,1,0,3,0,77,8,0,1,0,3,0,
        80,8,0,1,0,3,0,83,8,0,1,0,3,0,86,8,0,1,0,3,0,89,8,0,1,0,3,0,92,8,
        0,1,0,1,0,1,1,1,1,1,1,1,1,5,1,100,8,1,10,1,12,1,103,9,1,1,1,1,1,
        1,2,1,2,1,2,1,3,1,3,1,3,1,4,1,4,1,4,1,4,5,4,117,8,4,10,4,12,4,120,
        9,4,1,4,1,4,1,5,1,5,1,5,3,5,127,8,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,
        1,6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,147,8,7,1,8,1,8,
        1,8,4,8,152,8,8,11,8,12,8,153,1,8,1,8,1,9,3,9,159,8,9,1,9,1,9,3,
        9,163,8,9,1,9,3,9,166,8,9,1,9,1,9,1,9,4,9,171,8,9,11,9,12,9,172,
        1,9,1,9,3,9,177,8,9,1,10,1,10,1,10,1,11,1,11,1,11,1,11,5,11,186,
        8,11,10,11,12,11,189,9,11,3,11,191,8,11,1,11,1,11,1,12,1,12,3,12,
        197,8,12,1,13,1,13,3,13,201,8,13,1,14,1,14,1,15,1,15,1,15,1,15,1,
        15,1,15,3,15,211,8,15,1,16,1,16,1,16,1,16,5,16,217,8,16,10,16,12,
        16,220,9,16,3,16,222,8,16,1,16,1,16,1,17,1,17,1,17,1,17,3,17,230,
        8,17,1,18,1,18,1,18,1,18,5,18,236,8,18,10,18,12,18,239,9,18,3,18,
        241,8,18,1,18,1,18,1,19,1,19,1,19,1,19,5,19,249,8,19,10,19,12,19,
        252,9,19,1,19,1,19,1,20,1,20,1,20,1,21,1,21,1,21,1,21,1,21,1,21,
        1,21,1,21,1,21,3,21,268,8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,
        1,21,1,21,1,21,1,21,1,21,5,21,282,8,21,10,21,12,21,285,9,21,1,22,
        1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,
        1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,311,8,22,
        1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,3,23,323,8,23,
        1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,5,23,
        337,8,23,10,23,12,23,340,9,23,1,24,1,24,1,24,1,24,1,24,3,24,347,
        8,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,357,8,24,1,24,
        1,24,1,24,1,24,1,24,3,24,364,8,24,1,25,1,25,1,25,1,25,1,25,1,26,
        1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,3,26,381,8,26,1,27,
        1,27,1,27,5,27,386,8,27,10,27,12,27,389,9,27,1,27,1,27,1,28,1,28,
        1,29,1,29,1,30,1,30,1,30,1,30,3,30,401,8,30,3,30,403,8,30,1,31,1,
        31,1,32,1,32,1,32,0,2,42,46,33,0,2,4,6,8,10,12,14,16,18,20,22,24,
        26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,0,4,
        1,0,60,61,2,0,15,17,58,58,2,0,18,19,58,58,1,0,20,23,442,0,67,1,0,
        0,0,2,95,1,0,0,0,4,106,1,0,0,0,6,109,1,0,0,0,8,112,1,0,0,0,10,123,
        1,0,0,0,12,130,1,0,0,0,14,146,1,0,0,0,16,148,1,0,0,0,18,158,1,0,
        0,0,20,178,1,0,0,0,22,181,1,0,0,0,24,196,1,0,0,0,26,198,1,0,0,0,
        28,202,1,0,0,0,30,210,1,0,0,0,32,212,1,0,0,0,34,229,1,0,0,0,36,231,
        1,0,0,0,38,244,1,0,0,0,40,255,1,0,0,0,42,267,1,0,0,0,44,310,1,0,
        0,0,46,322,1,0,0,0,48,363,1,0,0,0,50,365,1,0,0,0,52,380,1,0,0,0,
        54,387,1,0,0,0,56,392,1,0,0,0,58,394,1,0,0,0,60,396,1,0,0,0,62,404,
        1,0,0,0,64,406,1,0,0,0,66,68,3,6,3,0,67,66,1,0,0,0,67,68,1,0,0,0,
        68,70,1,0,0,0,69,71,5,32,0,0,70,69,1,0,0,0,70,71,1,0,0,0,71,73,1,
        0,0,0,72,74,3,2,1,0,73,72,1,0,0,0,73,74,1,0,0,0,74,76,1,0,0,0,75,
        77,5,32,0,0,76,75,1,0,0,0,76,77,1,0,0,0,77,79,1,0,0,0,78,80,3,8,
        4,0,79,78,1,0,0,0,79,80,1,0,0,0,80,82,1,0,0,0,81,83,5,32,0,0,82,
        81,1,0,0,0,82,83,1,0,0,0,83,85,1,0,0,0,84,86,3,12,6,0,85,84,1,0,
        0,0,85,86,1,0,0,0,86,88,1,0,0,0,87,89,5,32,0,0,88,87,1,0,0,0,88,
        89,1,0,0,0,89,91,1,0,0,0,90,92,3,38,19,0,91,90,1,0,0,0,91,92,1,0,
        0,0,92,93,1,0,0,0,93,94,5,0,0,1,94,1,1,0,0,0,95,96,5,1,0,0,96,97,
        5,32,0,0,97,101,5,33,0,0,98,100,3,4,2,0,99,98,1,0,0,0,100,103,1,
        0,0,0,101,99,1,0,0,0,101,102,1,0,0,0,102,104,1,0,0,0,103,101,1,0,
        0,0,104,105,5,34,0,0,105,3,1,0,0,0,106,107,3,60,30,0,107,108,5,32,
        0,0,108,5,1,0,0,0,109,110,5,2,0,0,110,111,3,54,27,0,111,7,1,0,0,
        0,112,113,5,3,0,0,113,114,5,32,0,0,114,118,5,33,0,0,115,117,3,10,
        5,0,116,115,1,0,0,0,117,120,1,0,0,0,118,116,1,0,0,0,118,119,1,0,
        0,0,119,121,1,0,0,0,120,118,1,0,0,0,121,122,5,34,0,0,122,9,1,0,0,
        0,123,126,3,54,27,0,124,125,5,4,0,0,125,127,3,54,27,0,126,124,1,
        0,0,0,126,127,1,0,0,0,127,128,1,0,0,0,128,129,5,32,0,0,129,11,1,
        0,0,0,130,131,5,5,0,0,131,132,5,32,0,0,132,133,5,33,0,0,133,134,
        3,18,9,0,134,135,5,34,0,0,135,13,1,0,0,0,136,137,5,35,0,0,137,147,
        3,16,8,0,138,139,5,36,0,0,139,147,3,16,8,0,140,141,5,37,0,0,141,
        147,3,16,8,0,142,143,5,38,0,0,143,147,3,16,8,0,144,145,5,39,0,0,
        145,147,3,16,8,0,146,136,1,0,0,0,146,138,1,0,0,0,146,140,1,0,0,0,
        146,142,1,0,0,0,146,144,1,0,0,0,147,15,1,0,0,0,148,149,5,32,0,0,
        149,151,5,33,0,0,150,152,3,18,9,0,151,150,1,0,0,0,152,153,1,0,0,
        0,153,151,1,0,0,0,153,154,1,0,0,0,154,155,1,0,0,0,155,156,5,34,0,
        0,156,17,1,0,0,0,157,159,3,58,29,0,158,157,1,0,0,0,158,159,1,0,0,
        0,159,160,1,0,0,0,160,162,3,54,27,0,161,163,3,20,10,0,162,161,1,
        0,0,0,162,163,1,0,0,0,163,165,1,0,0,0,164,166,3,22,11,0,165,164,
        1,0,0,0,165,166,1,0,0,0,166,167,1,0,0,0,167,176,5,32,0,0,168,170,
        5,33,0,0,169,171,3,14,7,0,170,169,1,0,0,0,171,172,1,0,0,0,172,170,
        1,0,0,0,172,173,1,0,0,0,173,174,1,0,0,0,174,175,5,34,0,0,175,177,
        1,0,0,0,176,168,1,0,0,0,176,177,1,0,0,0,177,19,1,0,0,0,178,179,5,
        6,0,0,179,180,5,39,0,0,180,21,1,0,0,0,181,190,5,28,0,0,182,187,3,
        24,12,0,183,184,5,59,0,0,184,186,3,24,12,0,185,183,1,0,0,0,186,189,
        1,0,0,0,187,185,1,0,0,0,187,188,1,0,0,0,188,191,1,0,0,0,189,187,
        1,0,0,0,190,182,1,0,0,0,190,191,1,0,0,0,191,192,1,0,0,0,192,193,
        5,29,0,0,193,23,1,0,0,0,194,197,3,26,13,0,195,197,3,34,17,0,196,
        194,1,0,0,0,196,195,1,0,0,0,197,25,1,0,0,0,198,200,3,28,14,0,199,
        201,3,30,15,0,200,199,1,0,0,0,200,201,1,0,0,0,201,27,1,0,0,0,202,
        203,3,56,28,0,203,29,1,0,0,0,204,211,5,57,0,0,205,211,5,55,0,0,206,
        211,5,56,0,0,207,211,5,62,0,0,208,211,3,22,11,0,209,211,3,32,16,
        0,210,204,1,0,0,0,210,205,1,0,0,0,210,206,1,0,0,0,210,207,1,0,0,
        0,210,208,1,0,0,0,210,209,1,0,0,0,211,31,1,0,0,0,212,221,5,26,0,
        0,213,218,3,30,15,0,214,215,5,59,0,0,215,217,3,30,15,0,216,214,1,
        0,0,0,217,220,1,0,0,0,218,216,1,0,0,0,218,219,1,0,0,0,219,222,1,
        0,0,0,220,218,1,0,0,0,221,213,1,0,0,0,221,222,1,0,0,0,222,223,1,
        0,0,0,223,224,5,27,0,0,224,33,1,0,0,0,225,226,5,7,0,0,226,230,3,
        42,21,0,227,228,5,8,0,0,228,230,3,36,18,0,229,225,1,0,0,0,229,227,
        1,0,0,0,230,35,1,0,0,0,231,240,5,26,0,0,232,237,3,42,21,0,233,234,
        5,59,0,0,234,236,3,42,21,0,235,233,1,0,0,0,236,239,1,0,0,0,237,235,
        1,0,0,0,237,238,1,0,0,0,238,241,1,0,0,0,239,237,1,0,0,0,240,232,
        1,0,0,0,240,241,1,0,0,0,241,242,1,0,0,0,242,243,5,27,0,0,243,37,
        1,0,0,0,244,245,5,8,0,0,245,246,5,32,0,0,246,250,5,33,0,0,247,249,
        3,40,20,0,248,247,1,0,0,0,249,252,1,0,0,0,250,248,1,0,0,0,250,251,
        1,0,0,0,251,253,1,0,0,0,252,250,1,0,0,0,253,254,5,34,0,0,254,39,
        1,0,0,0,255,256,3,42,21,0,256,257,5,32,0,0,257,41,1,0,0,0,258,259,
        6,21,-1,0,259,268,3,44,22,0,260,268,3,54,27,0,261,262,5,24,0,0,262,
        263,3,42,21,0,263,264,5,25,0,0,264,268,1,0,0,0,265,266,5,40,0,0,
        266,268,3,42,21,5,267,258,1,0,0,0,267,260,1,0,0,0,267,261,1,0,0,
        0,267,265,1,0,0,0,268,283,1,0,0,0,269,270,10,4,0,0,270,271,5,41,
        0,0,271,282,3,42,21,5,272,273,10,3,0,0,273,274,5,42,0,0,274,282,
        3,42,21,4,275,276,10,2,0,0,276,277,5,44,0,0,277,282,3,42,21,3,278,
        279,10,1,0,0,279,280,5,43,0,0,280,282,3,42,21,2,281,269,1,0,0,0,
        281,272,1,0,0,0,281,275,1,0,0,0,281,278,1,0,0,0,282,285,1,0,0,0,
        283,281,1,0,0,0,283,284,1,0,0,0,284,43,1,0,0,0,285,283,1,0,0,0,286,
        287,3,46,23,0,287,288,5,45,0,0,288,289,3,46,23,0,289,311,1,0,0,0,
        290,291,3,46,23,0,291,292,5,46,0,0,292,293,3,46,23,0,293,311,1,0,
        0,0,294,295,3,46,23,0,295,296,5,48,0,0,296,297,3,46,23,0,297,311,
        1,0,0,0,298,299,3,46,23,0,299,300,5,47,0,0,300,301,3,46,23,0,301,
        311,1,0,0,0,302,303,3,46,23,0,303,304,5,49,0,0,304,305,3,46,23,0,
        305,311,1,0,0,0,306,307,3,46,23,0,307,308,5,50,0,0,308,309,3,46,
        23,0,309,311,1,0,0,0,310,286,1,0,0,0,310,290,1,0,0,0,310,294,1,0,
        0,0,310,298,1,0,0,0,310,302,1,0,0,0,310,306,1,0,0,0,311,45,1,0,0,
        0,312,313,6,23,-1,0,313,323,5,55,0,0,314,323,5,56,0,0,315,323,5,
        62,0,0,316,323,3,48,24,0,317,323,3,54,27,0,318,319,5,24,0,0,319,
        320,3,46,23,0,320,321,5,25,0,0,321,323,1,0,0,0,322,312,1,0,0,0,322,
        314,1,0,0,0,322,315,1,0,0,0,322,316,1,0,0,0,322,317,1,0,0,0,322,
        318,1,0,0,0,323,338,1,0,0,0,324,325,10,4,0,0,325,326,5,53,0,0,326,
        337,3,46,23,5,327,328,10,3,0,0,328,329,5,54,0,0,329,337,3,46,23,
        4,330,331,10,2,0,0,331,332,5,52,0,0,332,337,3,46,23,3,333,334,10,
        1,0,0,334,335,5,51,0,0,335,337,3,46,23,2,336,324,1,0,0,0,336,327,
        1,0,0,0,336,330,1,0,0,0,336,333,1,0,0,0,337,340,1,0,0,0,338,336,
        1,0,0,0,338,339,1,0,0,0,339,47,1,0,0,0,340,338,1,0,0,0,341,342,5,
        9,0,0,342,346,5,24,0,0,343,344,3,54,27,0,344,345,5,59,0,0,345,347,
        1,0,0,0,346,343,1,0,0,0,346,347,1,0,0,0,347,348,1,0,0,0,348,349,
        3,54,27,0,349,350,5,25,0,0,350,364,1,0,0,0,351,352,5,10,0,0,352,
        356,5,24,0,0,353,354,3,54,27,0,354,355,5,59,0,0,355,357,1,0,0,0,
        356,353,1,0,0,0,356,357,1,0,0,0,357,358,1,0,0,0,358,359,3,54,27,
        0,359,360,5,25,0,0,360,364,1,0,0,0,361,364,3,50,25,0,362,364,3,52,
        26,0,363,341,1,0,0,0,363,351,1,0,0,0,363,361,1,0,0,0,363,362,1,0,
        0,0,364,49,1,0,0,0,365,366,5,11,0,0,366,367,5,24,0,0,367,368,3,54,
        27,0,368,369,5,25,0,0,369,51,1,0,0,0,370,371,5,12,0,0,371,372,5,
        24,0,0,372,373,3,54,27,0,373,374,5,25,0,0,374,381,1,0,0,0,375,376,
        5,13,0,0,376,377,5,24,0,0,377,378,3,54,27,0,378,379,5,25,0,0,379,
        381,1,0,0,0,380,370,1,0,0,0,380,375,1,0,0,0,381,53,1,0,0,0,382,383,
        3,56,28,0,383,384,5,14,0,0,384,386,1,0,0,0,385,382,1,0,0,0,386,389,
        1,0,0,0,387,385,1,0,0,0,387,388,1,0,0,0,388,390,1,0,0,0,389,387,
        1,0,0,0,390,391,3,56,28,0,391,55,1,0,0,0,392,393,7,0,0,0,393,57,
        1,0,0,0,394,395,7,1,0,0,395,59,1,0,0,0,396,402,3,62,31,0,397,400,
        5,14,0,0,398,401,3,64,32,0,399,401,5,52,0,0,400,398,1,0,0,0,400,
        399,1,0,0,0,401,403,1,0,0,0,402,397,1,0,0,0,402,403,1,0,0,0,403,
        61,1,0,0,0,404,405,7,2,0,0,405,63,1,0,0,0,406,407,7,3,0,0,407,65,
        1,0,0,0,44,67,70,73,76,79,82,85,88,91,101,118,126,146,153,158,162,
        165,172,176,187,190,196,200,210,218,221,229,237,240,250,267,281,
        283,310,322,336,338,346,356,363,380,387,400,402
    ]

class UVLPythonParser ( Parser ):

    grammarFileName = "UVLPython.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'include'", "'namespace'", "'imports'", 
                     "'as'", "'features'", "'cardinality'", "'constraint'", 
                     "'constraints'", "'sum'", "'avg'", "'len'", "'floor'", 
                     "'ceil'", "'.'", "'String'", "'Integer'", "'Real'", 
                     "'Arithmetic'", "'Type'", "'group-cardinality'", "'feature-cardinality'", 
                     "'aggregate-function'", "'string-constraints'", "'('", 
                     "')'", "'['", "']'", "'{'", "'}'", "'/*'", "'*/'", 
                     "<INVALID>", "'<INDENT>'", "'<DEDENT>'", "'or'", "'alternative'", 
                     "'optional'", "'mandatory'", "<INVALID>", "'!'", "'&'", 
                     "'|'", "'<=>'", "'=>'", "'=='", "'<'", "'<='", "'>'", 
                     "'>='", "'!='", "'/'", "'*'", "'+'", "'-'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'Boolean'", "','" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "OPEN_PAREN", "CLOSE_PAREN", "OPEN_BRACK", "CLOSE_BRACK", 
                      "OPEN_BRACE", "CLOSE_BRACE", "OPEN_COMMENT", "CLOSE_COMMENT", 
                      "NEWLINE", "INDENT", "DEDENT", "ORGROUP", "ALTERNATIVE", 
                      "OPTIONAL", "MANDATORY", "CARDINALITY", "NOT", "AND", 
                      "OR", "EQUIVALENCE", "IMPLICATION", "EQUAL", "LOWER", 
                      "LOWER_EQUALS", "GREATER", "GREATER_EQUALS", "NOT_EQUALS", 
                      "DIV", "MUL", "ADD", "SUB", "FLOAT", "INTEGER", "BOOLEAN", 
                      "BOOLEAN_KEY", "COMMA", "ID_NOT_STRICT", "ID_STRICT", 
                      "STRING", "SKIP_" ]

    RULE_featureModel = 0
    RULE_includes = 1
    RULE_includeLine = 2
    RULE_namespace = 3
    RULE_imports = 4
    RULE_importLine = 5
    RULE_features = 6
    RULE_group = 7
    RULE_groupSpec = 8
    RULE_feature = 9
    RULE_featureCardinality = 10
    RULE_attributes = 11
    RULE_attribute = 12
    RULE_valueAttribute = 13
    RULE_key = 14
    RULE_value = 15
    RULE_vector = 16
    RULE_constraintAttribute = 17
    RULE_constraintList = 18
    RULE_constraints = 19
    RULE_constraintLine = 20
    RULE_constraint = 21
    RULE_equation = 22
    RULE_expression = 23
    RULE_aggregateFunction = 24
    RULE_stringAggregateFunction = 25
    RULE_numericAggregateFunction = 26
    RULE_reference = 27
    RULE_id = 28
    RULE_featureType = 29
    RULE_languageLevel = 30
    RULE_majorLevel = 31
    RULE_minorLevel = 32

    ruleNames =  [ "featureModel", "includes", "includeLine", "namespace", 
                   "imports", "importLine", "features", "group", "groupSpec", 
                   "feature", "featureCardinality", "attributes", "attribute", 
                   "valueAttribute", "key", "value", "vector", "constraintAttribute", 
                   "constraintList", "constraints", "constraintLine", "constraint", 
                   "equation", "expression", "aggregateFunction", "stringAggregateFunction", 
                   "numericAggregateFunction", "reference", "id", "featureType", 
                   "languageLevel", "majorLevel", "minorLevel" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    OPEN_PAREN=24
    CLOSE_PAREN=25
    OPEN_BRACK=26
    CLOSE_BRACK=27
    OPEN_BRACE=28
    CLOSE_BRACE=29
    OPEN_COMMENT=30
    CLOSE_COMMENT=31
    NEWLINE=32
    INDENT=33
    DEDENT=34
    ORGROUP=35
    ALTERNATIVE=36
    OPTIONAL=37
    MANDATORY=38
    CARDINALITY=39
    NOT=40
    AND=41
    OR=42
    EQUIVALENCE=43
    IMPLICATION=44
    EQUAL=45
    LOWER=46
    LOWER_EQUALS=47
    GREATER=48
    GREATER_EQUALS=49
    NOT_EQUALS=50
    DIV=51
    MUL=52
    ADD=53
    SUB=54
    FLOAT=55
    INTEGER=56
    BOOLEAN=57
    BOOLEAN_KEY=58
    COMMA=59
    ID_NOT_STRICT=60
    ID_STRICT=61
    STRING=62
    SKIP_=63

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class FeatureModelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(UVLPythonParser.EOF, 0)

        def namespace(self):
            return self.getTypedRuleContext(UVLPythonParser.NamespaceContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.NEWLINE)
            else:
                return self.getToken(UVLPythonParser.NEWLINE, i)

        def includes(self):
            return self.getTypedRuleContext(UVLPythonParser.IncludesContext,0)


        def imports(self):
            return self.getTypedRuleContext(UVLPythonParser.ImportsContext,0)


        def features(self):
            return self.getTypedRuleContext(UVLPythonParser.FeaturesContext,0)


        def constraints(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintsContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureModel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureModel" ):
                listener.enterFeatureModel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureModel" ):
                listener.exitFeatureModel(self)




    def featureModel(self):

        localctx = UVLPythonParser.FeatureModelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_featureModel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 67
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2:
                self.state = 66
                self.namespace()


            self.state = 70
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 69
                self.match(UVLPythonParser.NEWLINE)


            self.state = 73
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 72
                self.includes()


            self.state = 76
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 75
                self.match(UVLPythonParser.NEWLINE)


            self.state = 79
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3:
                self.state = 78
                self.imports()


            self.state = 82
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 81
                self.match(UVLPythonParser.NEWLINE)


            self.state = 85
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 84
                self.features()


            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 87
                self.match(UVLPythonParser.NEWLINE)


            self.state = 91
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 90
                self.constraints()


            self.state = 93
            self.match(UVLPythonParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def includeLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.IncludeLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.IncludeLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_includes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludes" ):
                listener.enterIncludes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludes" ):
                listener.exitIncludes(self)




    def includes(self):

        localctx = UVLPythonParser.IncludesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_includes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.match(UVLPythonParser.T__0)
            self.state = 96
            self.match(UVLPythonParser.NEWLINE)
            self.state = 97
            self.match(UVLPythonParser.INDENT)
            self.state = 101
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 288230376152498176) != 0):
                self.state = 98
                self.includeLine()
                self.state = 103
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 104
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def languageLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.LanguageLevelContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_includeLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludeLine" ):
                listener.enterIncludeLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludeLine" ):
                listener.exitIncludeLine(self)




    def includeLine(self):

        localctx = UVLPythonParser.IncludeLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_includeLine)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 106
            self.languageLevel()
            self.state = 107
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NamespaceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_namespace

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNamespace" ):
                listener.enterNamespace(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNamespace" ):
                listener.exitNamespace(self)




    def namespace(self):

        localctx = UVLPythonParser.NamespaceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_namespace)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self.match(UVLPythonParser.T__1)
            self.state = 110
            self.reference()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def importLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ImportLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ImportLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_imports

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImports" ):
                listener.enterImports(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImports" ):
                listener.exitImports(self)




    def imports(self):

        localctx = UVLPythonParser.ImportsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_imports)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112
            self.match(UVLPythonParser.T__2)
            self.state = 113
            self.match(UVLPythonParser.NEWLINE)
            self.state = 114
            self.match(UVLPythonParser.INDENT)
            self.state = 118
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==60 or _la==61:
                self.state = 115
                self.importLine()
                self.state = 120
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 121
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.ns = None # ReferenceContext
            self.alias = None # ReferenceContext

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_importLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImportLine" ):
                listener.enterImportLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImportLine" ):
                listener.exitImportLine(self)




    def importLine(self):

        localctx = UVLPythonParser.ImportLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_importLine)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 123
            localctx.ns = self.reference()
            self.state = 126
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4:
                self.state = 124
                self.match(UVLPythonParser.T__3)
                self.state = 125
                localctx.alias = self.reference()


            self.state = 128
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeaturesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def feature(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureContext,0)


        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_features

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatures" ):
                listener.enterFeatures(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatures" ):
                listener.exitFeatures(self)




    def features(self):

        localctx = UVLPythonParser.FeaturesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_features)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            self.match(UVLPythonParser.T__4)
            self.state = 131
            self.match(UVLPythonParser.NEWLINE)
            self.state = 132
            self.match(UVLPythonParser.INDENT)
            self.state = 133
            self.feature()
            self.state = 134
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_group

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AlternativeGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ALTERNATIVE(self):
            return self.getToken(UVLPythonParser.ALTERNATIVE, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlternativeGroup" ):
                listener.enterAlternativeGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlternativeGroup" ):
                listener.exitAlternativeGroup(self)


    class OptionalGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPTIONAL(self):
            return self.getToken(UVLPythonParser.OPTIONAL, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionalGroup" ):
                listener.enterOptionalGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionalGroup" ):
                listener.exitOptionalGroup(self)


    class MandatoryGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MANDATORY(self):
            return self.getToken(UVLPythonParser.MANDATORY, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMandatoryGroup" ):
                listener.enterMandatoryGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMandatoryGroup" ):
                listener.exitMandatoryGroup(self)


    class CardinalityGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CARDINALITY(self):
            return self.getToken(UVLPythonParser.CARDINALITY, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCardinalityGroup" ):
                listener.enterCardinalityGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCardinalityGroup" ):
                listener.exitCardinalityGroup(self)


    class OrGroupContext(GroupContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.GroupContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ORGROUP(self):
            return self.getToken(UVLPythonParser.ORGROUP, 0)
        def groupSpec(self):
            return self.getTypedRuleContext(UVLPythonParser.GroupSpecContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrGroup" ):
                listener.enterOrGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrGroup" ):
                listener.exitOrGroup(self)



    def group(self):

        localctx = UVLPythonParser.GroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_group)
        try:
            self.state = 146
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [35]:
                localctx = UVLPythonParser.OrGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 136
                self.match(UVLPythonParser.ORGROUP)
                self.state = 137
                self.groupSpec()
                pass
            elif token in [36]:
                localctx = UVLPythonParser.AlternativeGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 138
                self.match(UVLPythonParser.ALTERNATIVE)
                self.state = 139
                self.groupSpec()
                pass
            elif token in [37]:
                localctx = UVLPythonParser.OptionalGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 140
                self.match(UVLPythonParser.OPTIONAL)
                self.state = 141
                self.groupSpec()
                pass
            elif token in [38]:
                localctx = UVLPythonParser.MandatoryGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 142
                self.match(UVLPythonParser.MANDATORY)
                self.state = 143
                self.groupSpec()
                pass
            elif token in [39]:
                localctx = UVLPythonParser.CardinalityGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 144
                self.match(UVLPythonParser.CARDINALITY)
                self.state = 145
                self.groupSpec()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def feature(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.FeatureContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.FeatureContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_groupSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupSpec" ):
                listener.enterGroupSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupSpec" ):
                listener.exitGroupSpec(self)




    def groupSpec(self):

        localctx = UVLPythonParser.GroupSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_groupSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.match(UVLPythonParser.NEWLINE)
            self.state = 149
            self.match(UVLPythonParser.INDENT)
            self.state = 151 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 150
                self.feature()
                self.state = 153 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 3746994889972482048) != 0)):
                    break

            self.state = 155
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def featureType(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureTypeContext,0)


        def featureCardinality(self):
            return self.getTypedRuleContext(UVLPythonParser.FeatureCardinalityContext,0)


        def attributes(self):
            return self.getTypedRuleContext(UVLPythonParser.AttributesContext,0)


        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def group(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.GroupContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.GroupContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_feature

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeature" ):
                listener.enterFeature(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeature" ):
                listener.exitFeature(self)




    def feature(self):

        localctx = UVLPythonParser.FeatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_feature)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 288230376151941120) != 0):
                self.state = 157
                self.featureType()


            self.state = 160
            self.reference()
            self.state = 162
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 161
                self.featureCardinality()


            self.state = 165
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==28:
                self.state = 164
                self.attributes()


            self.state = 167
            self.match(UVLPythonParser.NEWLINE)
            self.state = 176
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 168
                self.match(UVLPythonParser.INDENT)
                self.state = 170 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 169
                    self.group()
                    self.state = 172 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 1065151889408) != 0)):
                        break

                self.state = 174
                self.match(UVLPythonParser.DEDENT)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureCardinalityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CARDINALITY(self):
            return self.getToken(UVLPythonParser.CARDINALITY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureCardinality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureCardinality" ):
                listener.enterFeatureCardinality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureCardinality" ):
                listener.exitFeatureCardinality(self)




    def featureCardinality(self):

        localctx = UVLPythonParser.FeatureCardinalityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_featureCardinality)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            self.match(UVLPythonParser.T__5)
            self.state = 179
            self.match(UVLPythonParser.CARDINALITY)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACE(self):
            return self.getToken(UVLPythonParser.OPEN_BRACE, 0)

        def CLOSE_BRACE(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACE, 0)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.AttributeContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.AttributeContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_attributes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributes" ):
                listener.enterAttributes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributes" ):
                listener.exitAttributes(self)




    def attributes(self):

        localctx = UVLPythonParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 181
            self.match(UVLPythonParser.OPEN_BRACE)
            self.state = 190
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3458764513820541312) != 0):
                self.state = 182
                self.attribute()
                self.state = 187
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==59:
                    self.state = 183
                    self.match(UVLPythonParser.COMMA)
                    self.state = 184
                    self.attribute()
                    self.state = 189
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 192
            self.match(UVLPythonParser.CLOSE_BRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def valueAttribute(self):
            return self.getTypedRuleContext(UVLPythonParser.ValueAttributeContext,0)


        def constraintAttribute(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintAttributeContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = UVLPythonParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_attribute)
        try:
            self.state = 196
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [60, 61]:
                self.enterOuterAlt(localctx, 1)
                self.state = 194
                self.valueAttribute()
                pass
            elif token in [7, 8]:
                self.enterOuterAlt(localctx, 2)
                self.state = 195
                self.constraintAttribute()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueAttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def key(self):
            return self.getTypedRuleContext(UVLPythonParser.KeyContext,0)


        def value(self):
            return self.getTypedRuleContext(UVLPythonParser.ValueContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_valueAttribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueAttribute" ):
                listener.enterValueAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueAttribute" ):
                listener.exitValueAttribute(self)




    def valueAttribute(self):

        localctx = UVLPythonParser.ValueAttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_valueAttribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198
            self.key()
            self.state = 200
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4863887597895680000) != 0):
                self.state = 199
                self.value()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(UVLPythonParser.IdContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_key

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKey" ):
                listener.enterKey(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKey" ):
                listener.exitKey(self)




    def key(self):

        localctx = UVLPythonParser.KeyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_key)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.id_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOLEAN(self):
            return self.getToken(UVLPythonParser.BOOLEAN, 0)

        def FLOAT(self):
            return self.getToken(UVLPythonParser.FLOAT, 0)

        def INTEGER(self):
            return self.getToken(UVLPythonParser.INTEGER, 0)

        def STRING(self):
            return self.getToken(UVLPythonParser.STRING, 0)

        def attributes(self):
            return self.getTypedRuleContext(UVLPythonParser.AttributesContext,0)


        def vector(self):
            return self.getTypedRuleContext(UVLPythonParser.VectorContext,0)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)




    def value(self):

        localctx = UVLPythonParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_value)
        try:
            self.state = 210
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [57]:
                self.enterOuterAlt(localctx, 1)
                self.state = 204
                self.match(UVLPythonParser.BOOLEAN)
                pass
            elif token in [55]:
                self.enterOuterAlt(localctx, 2)
                self.state = 205
                self.match(UVLPythonParser.FLOAT)
                pass
            elif token in [56]:
                self.enterOuterAlt(localctx, 3)
                self.state = 206
                self.match(UVLPythonParser.INTEGER)
                pass
            elif token in [62]:
                self.enterOuterAlt(localctx, 4)
                self.state = 207
                self.match(UVLPythonParser.STRING)
                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 5)
                self.state = 208
                self.attributes()
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 6)
                self.state = 209
                self.vector()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VectorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACK(self):
            return self.getToken(UVLPythonParser.OPEN_BRACK, 0)

        def CLOSE_BRACK(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACK, 0)

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ValueContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ValueContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_vector

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVector" ):
                listener.enterVector(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVector" ):
                listener.exitVector(self)




    def vector(self):

        localctx = UVLPythonParser.VectorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_vector)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.match(UVLPythonParser.OPEN_BRACK)
            self.state = 221
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4863887597895680000) != 0):
                self.state = 213
                self.value()
                self.state = 218
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==59:
                    self.state = 214
                    self.match(UVLPythonParser.COMMA)
                    self.state = 215
                    self.value()
                    self.state = 220
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 223
            self.match(UVLPythonParser.CLOSE_BRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintAttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintAttribute

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ListConstraintAttributeContext(ConstraintAttributeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintAttributeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraintList(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListConstraintAttribute" ):
                listener.enterListConstraintAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListConstraintAttribute" ):
                listener.exitListConstraintAttribute(self)


    class SingleConstraintAttributeContext(ConstraintAttributeContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintAttributeContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingleConstraintAttribute" ):
                listener.enterSingleConstraintAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingleConstraintAttribute" ):
                listener.exitSingleConstraintAttribute(self)



    def constraintAttribute(self):

        localctx = UVLPythonParser.ConstraintAttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_constraintAttribute)
        try:
            self.state = 229
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [7]:
                localctx = UVLPythonParser.SingleConstraintAttributeContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 225
                self.match(UVLPythonParser.T__6)
                self.state = 226
                self.constraint(0)
                pass
            elif token in [8]:
                localctx = UVLPythonParser.ListConstraintAttributeContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 227
                self.match(UVLPythonParser.T__7)
                self.state = 228
                self.constraintList()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_BRACK(self):
            return self.getToken(UVLPythonParser.OPEN_BRACK, 0)

        def CLOSE_BRACK(self):
            return self.getToken(UVLPythonParser.CLOSE_BRACK, 0)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(UVLPythonParser.COMMA)
            else:
                return self.getToken(UVLPythonParser.COMMA, i)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraintList" ):
                listener.enterConstraintList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraintList" ):
                listener.exitConstraintList(self)




    def constraintList(self):

        localctx = UVLPythonParser.ConstraintListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_constraintList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231
            self.match(UVLPythonParser.OPEN_BRACK)
            self.state = 240
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8178538022833241600) != 0):
                self.state = 232
                self.constraint(0)
                self.state = 237
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==59:
                    self.state = 233
                    self.match(UVLPythonParser.COMMA)
                    self.state = 234
                    self.constraint(0)
                    self.state = 239
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 242
            self.match(UVLPythonParser.CLOSE_BRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def INDENT(self):
            return self.getToken(UVLPythonParser.INDENT, 0)

        def DEDENT(self):
            return self.getToken(UVLPythonParser.DEDENT, 0)

        def constraintLine(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintLineContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintLineContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraints" ):
                listener.enterConstraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraints" ):
                listener.exitConstraints(self)




    def constraints(self):

        localctx = UVLPythonParser.ConstraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_constraints)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(UVLPythonParser.T__7)
            self.state = 245
            self.match(UVLPythonParser.NEWLINE)
            self.state = 246
            self.match(UVLPythonParser.INDENT)
            self.state = 250
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8178538022833241600) != 0):
                self.state = 247
                self.constraintLine()
                self.state = 252
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 253
            self.match(UVLPythonParser.DEDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintLineContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def NEWLINE(self):
            return self.getToken(UVLPythonParser.NEWLINE, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraintLine

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraintLine" ):
                listener.enterConstraintLine(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraintLine" ):
                listener.exitConstraintLine(self)




    def constraintLine(self):

        localctx = UVLPythonParser.ConstraintLineContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_constraintLine)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self.constraint(0)
            self.state = 256
            self.match(UVLPythonParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_constraint

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class OrConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def OR(self):
            return self.getToken(UVLPythonParser.OR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrConstraint" ):
                listener.enterOrConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrConstraint" ):
                listener.exitOrConstraint(self)


    class EquationConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def equation(self):
            return self.getTypedRuleContext(UVLPythonParser.EquationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquationConstraint" ):
                listener.enterEquationConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquationConstraint" ):
                listener.exitEquationConstraint(self)


    class LiteralConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralConstraint" ):
                listener.enterLiteralConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralConstraint" ):
                listener.exitLiteralConstraint(self)


    class ParenthesisConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesisConstraint" ):
                listener.enterParenthesisConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesisConstraint" ):
                listener.exitParenthesisConstraint(self)


    class NotConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(UVLPythonParser.NOT, 0)
        def constraint(self):
            return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotConstraint" ):
                listener.enterNotConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotConstraint" ):
                listener.exitNotConstraint(self)


    class AndConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def AND(self):
            return self.getToken(UVLPythonParser.AND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAndConstraint" ):
                listener.enterAndConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAndConstraint" ):
                listener.exitAndConstraint(self)


    class EquivalenceConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def EQUIVALENCE(self):
            return self.getToken(UVLPythonParser.EQUIVALENCE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquivalenceConstraint" ):
                listener.enterEquivalenceConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquivalenceConstraint" ):
                listener.exitEquivalenceConstraint(self)


    class ImplicationConstraintContext(ConstraintContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ConstraintContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ConstraintContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ConstraintContext,i)

        def IMPLICATION(self):
            return self.getToken(UVLPythonParser.IMPLICATION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImplicationConstraint" ):
                listener.enterImplicationConstraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImplicationConstraint" ):
                listener.exitImplicationConstraint(self)



    def constraint(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = UVLPythonParser.ConstraintContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 42
        self.enterRecursionRule(localctx, 42, self.RULE_constraint, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 267
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
            if la_ == 1:
                localctx = UVLPythonParser.EquationConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 259
                self.equation()
                pass

            elif la_ == 2:
                localctx = UVLPythonParser.LiteralConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 260
                self.reference()
                pass

            elif la_ == 3:
                localctx = UVLPythonParser.ParenthesisConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 261
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 262
                self.constraint(0)
                self.state = 263
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass

            elif la_ == 4:
                localctx = UVLPythonParser.NotConstraintContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 265
                self.match(UVLPythonParser.NOT)
                self.state = 266
                self.constraint(5)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 283
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,32,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 281
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                    if la_ == 1:
                        localctx = UVLPythonParser.AndConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 269
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 270
                        self.match(UVLPythonParser.AND)
                        self.state = 271
                        self.constraint(5)
                        pass

                    elif la_ == 2:
                        localctx = UVLPythonParser.OrConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 272
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 273
                        self.match(UVLPythonParser.OR)
                        self.state = 274
                        self.constraint(4)
                        pass

                    elif la_ == 3:
                        localctx = UVLPythonParser.ImplicationConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 275
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 276
                        self.match(UVLPythonParser.IMPLICATION)
                        self.state = 277
                        self.constraint(3)
                        pass

                    elif la_ == 4:
                        localctx = UVLPythonParser.EquivalenceConstraintContext(self, UVLPythonParser.ConstraintContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constraint)
                        self.state = 278
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 279
                        self.match(UVLPythonParser.EQUIVALENCE)
                        self.state = 280
                        self.constraint(2)
                        pass

             
                self.state = 285
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class EquationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_equation

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class EqualEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def EQUAL(self):
            return self.getToken(UVLPythonParser.EQUAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualEquation" ):
                listener.enterEqualEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualEquation" ):
                listener.exitEqualEquation(self)


    class LowerEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def LOWER(self):
            return self.getToken(UVLPythonParser.LOWER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLowerEquation" ):
                listener.enterLowerEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLowerEquation" ):
                listener.exitLowerEquation(self)


    class LowerEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def LOWER_EQUALS(self):
            return self.getToken(UVLPythonParser.LOWER_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLowerEqualsEquation" ):
                listener.enterLowerEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLowerEqualsEquation" ):
                listener.exitLowerEqualsEquation(self)


    class GreaterEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def GREATER_EQUALS(self):
            return self.getToken(UVLPythonParser.GREATER_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGreaterEqualsEquation" ):
                listener.enterGreaterEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGreaterEqualsEquation" ):
                listener.exitGreaterEqualsEquation(self)


    class GreaterEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def GREATER(self):
            return self.getToken(UVLPythonParser.GREATER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGreaterEquation" ):
                listener.enterGreaterEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGreaterEquation" ):
                listener.exitGreaterEquation(self)


    class NotEqualsEquationContext(EquationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.EquationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def NOT_EQUALS(self):
            return self.getToken(UVLPythonParser.NOT_EQUALS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotEqualsEquation" ):
                listener.enterNotEqualsEquation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotEqualsEquation" ):
                listener.exitNotEqualsEquation(self)



    def equation(self):

        localctx = UVLPythonParser.EquationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_equation)
        try:
            self.state = 310
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                localctx = UVLPythonParser.EqualEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 286
                self.expression(0)
                self.state = 287
                self.match(UVLPythonParser.EQUAL)
                self.state = 288
                self.expression(0)
                pass

            elif la_ == 2:
                localctx = UVLPythonParser.LowerEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 290
                self.expression(0)
                self.state = 291
                self.match(UVLPythonParser.LOWER)
                self.state = 292
                self.expression(0)
                pass

            elif la_ == 3:
                localctx = UVLPythonParser.GreaterEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 294
                self.expression(0)
                self.state = 295
                self.match(UVLPythonParser.GREATER)
                self.state = 296
                self.expression(0)
                pass

            elif la_ == 4:
                localctx = UVLPythonParser.LowerEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 298
                self.expression(0)
                self.state = 299
                self.match(UVLPythonParser.LOWER_EQUALS)
                self.state = 300
                self.expression(0)
                pass

            elif la_ == 5:
                localctx = UVLPythonParser.GreaterEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 302
                self.expression(0)
                self.state = 303
                self.match(UVLPythonParser.GREATER_EQUALS)
                self.state = 304
                self.expression(0)
                pass

            elif la_ == 6:
                localctx = UVLPythonParser.NotEqualsEquationContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 306
                self.expression(0)
                self.state = 307
                self.match(UVLPythonParser.NOT_EQUALS)
                self.state = 308
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class BracketExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBracketExpression" ):
                listener.enterBracketExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBracketExpression" ):
                listener.exitBracketExpression(self)


    class AggregateFunctionExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def aggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.AggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAggregateFunctionExpression" ):
                listener.enterAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAggregateFunctionExpression" ):
                listener.exitAggregateFunctionExpression(self)


    class FloatLiteralExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(UVLPythonParser.FLOAT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatLiteralExpression" ):
                listener.enterFloatLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatLiteralExpression" ):
                listener.exitFloatLiteralExpression(self)


    class StringLiteralExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(UVLPythonParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringLiteralExpression" ):
                listener.enterStringLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringLiteralExpression" ):
                listener.exitStringLiteralExpression(self)


    class AddExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def ADD(self):
            return self.getToken(UVLPythonParser.ADD, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddExpression" ):
                listener.enterAddExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddExpression" ):
                listener.exitAddExpression(self)


    class IntegerLiteralExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(UVLPythonParser.INTEGER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntegerLiteralExpression" ):
                listener.enterIntegerLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntegerLiteralExpression" ):
                listener.exitIntegerLiteralExpression(self)


    class LiteralExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpression" ):
                listener.enterLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpression" ):
                listener.exitLiteralExpression(self)


    class DivExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def DIV(self):
            return self.getToken(UVLPythonParser.DIV, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDivExpression" ):
                listener.enterDivExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDivExpression" ):
                listener.exitDivExpression(self)


    class SubExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def SUB(self):
            return self.getToken(UVLPythonParser.SUB, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubExpression" ):
                listener.enterSubExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubExpression" ):
                listener.exitSubExpression(self)


    class MulExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ExpressionContext,i)

        def MUL(self):
            return self.getToken(UVLPythonParser.MUL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulExpression" ):
                listener.enterMulExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulExpression" ):
                listener.exitMulExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = UVLPythonParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 46
        self.enterRecursionRule(localctx, 46, self.RULE_expression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [55]:
                localctx = UVLPythonParser.FloatLiteralExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 313
                self.match(UVLPythonParser.FLOAT)
                pass
            elif token in [56]:
                localctx = UVLPythonParser.IntegerLiteralExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 314
                self.match(UVLPythonParser.INTEGER)
                pass
            elif token in [62]:
                localctx = UVLPythonParser.StringLiteralExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 315
                self.match(UVLPythonParser.STRING)
                pass
            elif token in [9, 10, 11, 12, 13]:
                localctx = UVLPythonParser.AggregateFunctionExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 316
                self.aggregateFunction()
                pass
            elif token in [60, 61]:
                localctx = UVLPythonParser.LiteralExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 317
                self.reference()
                pass
            elif token in [24]:
                localctx = UVLPythonParser.BracketExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 318
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 319
                self.expression(0)
                self.state = 320
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 338
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,36,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 336
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
                    if la_ == 1:
                        localctx = UVLPythonParser.AddExpressionContext(self, UVLPythonParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 324
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 325
                        self.match(UVLPythonParser.ADD)
                        self.state = 326
                        self.expression(5)
                        pass

                    elif la_ == 2:
                        localctx = UVLPythonParser.SubExpressionContext(self, UVLPythonParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 327
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 328
                        self.match(UVLPythonParser.SUB)
                        self.state = 329
                        self.expression(4)
                        pass

                    elif la_ == 3:
                        localctx = UVLPythonParser.MulExpressionContext(self, UVLPythonParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 330
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 331
                        self.match(UVLPythonParser.MUL)
                        self.state = 332
                        self.expression(3)
                        pass

                    elif la_ == 4:
                        localctx = UVLPythonParser.DivExpressionContext(self, UVLPythonParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 333
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 334
                        self.match(UVLPythonParser.DIV)
                        self.state = 335
                        self.expression(2)
                        pass

             
                self.state = 340
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,36,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_aggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AvgAggregateFunctionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)
        def COMMA(self):
            return self.getToken(UVLPythonParser.COMMA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAvgAggregateFunction" ):
                listener.enterAvgAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAvgAggregateFunction" ):
                listener.exitAvgAggregateFunction(self)


    class NumericAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def numericAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.NumericAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumericAggregateFunctionExpression" ):
                listener.enterNumericAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumericAggregateFunctionExpression" ):
                listener.exitNumericAggregateFunctionExpression(self)


    class SumAggregateFunctionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.ReferenceContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,i)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)
        def COMMA(self):
            return self.getToken(UVLPythonParser.COMMA, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumAggregateFunction" ):
                listener.enterSumAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumAggregateFunction" ):
                listener.exitSumAggregateFunction(self)


    class StringAggregateFunctionExpressionContext(AggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.AggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def stringAggregateFunction(self):
            return self.getTypedRuleContext(UVLPythonParser.StringAggregateFunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringAggregateFunctionExpression" ):
                listener.enterStringAggregateFunctionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringAggregateFunctionExpression" ):
                listener.exitStringAggregateFunctionExpression(self)



    def aggregateFunction(self):

        localctx = UVLPythonParser.AggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_aggregateFunction)
        try:
            self.state = 363
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                localctx = UVLPythonParser.SumAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 341
                self.match(UVLPythonParser.T__8)
                self.state = 342
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 346
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
                if la_ == 1:
                    self.state = 343
                    self.reference()
                    self.state = 344
                    self.match(UVLPythonParser.COMMA)


                self.state = 348
                self.reference()
                self.state = 349
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            elif token in [10]:
                localctx = UVLPythonParser.AvgAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 351
                self.match(UVLPythonParser.T__9)
                self.state = 352
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 356
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
                if la_ == 1:
                    self.state = 353
                    self.reference()
                    self.state = 354
                    self.match(UVLPythonParser.COMMA)


                self.state = 358
                self.reference()
                self.state = 359
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            elif token in [11]:
                localctx = UVLPythonParser.StringAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 361
                self.stringAggregateFunction()
                pass
            elif token in [12, 13]:
                localctx = UVLPythonParser.NumericAggregateFunctionExpressionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 362
                self.numericAggregateFunction()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_stringAggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LengthAggregateFunctionContext(StringAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.StringAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLengthAggregateFunction" ):
                listener.enterLengthAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLengthAggregateFunction" ):
                listener.exitLengthAggregateFunction(self)



    def stringAggregateFunction(self):

        localctx = UVLPythonParser.StringAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_stringAggregateFunction)
        try:
            localctx = UVLPythonParser.LengthAggregateFunctionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 365
            self.match(UVLPythonParser.T__10)
            self.state = 366
            self.match(UVLPythonParser.OPEN_PAREN)
            self.state = 367
            self.reference()
            self.state = 368
            self.match(UVLPythonParser.CLOSE_PAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumericAggregateFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_numericAggregateFunction

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CeilAggregateFunctionContext(NumericAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.NumericAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCeilAggregateFunction" ):
                listener.enterCeilAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCeilAggregateFunction" ):
                listener.exitCeilAggregateFunction(self)


    class FloorAggregateFunctionContext(NumericAggregateFunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a UVLPythonParser.NumericAggregateFunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(UVLPythonParser.OPEN_PAREN, 0)
        def reference(self):
            return self.getTypedRuleContext(UVLPythonParser.ReferenceContext,0)

        def CLOSE_PAREN(self):
            return self.getToken(UVLPythonParser.CLOSE_PAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloorAggregateFunction" ):
                listener.enterFloorAggregateFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloorAggregateFunction" ):
                listener.exitFloorAggregateFunction(self)



    def numericAggregateFunction(self):

        localctx = UVLPythonParser.NumericAggregateFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_numericAggregateFunction)
        try:
            self.state = 380
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12]:
                localctx = UVLPythonParser.FloorAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 370
                self.match(UVLPythonParser.T__11)
                self.state = 371
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 372
                self.reference()
                self.state = 373
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            elif token in [13]:
                localctx = UVLPythonParser.CeilAggregateFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 375
                self.match(UVLPythonParser.T__12)
                self.state = 376
                self.match(UVLPythonParser.OPEN_PAREN)
                self.state = 377
                self.reference()
                self.state = 378
                self.match(UVLPythonParser.CLOSE_PAREN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(UVLPythonParser.IdContext)
            else:
                return self.getTypedRuleContext(UVLPythonParser.IdContext,i)


        def getRuleIndex(self):
            return UVLPythonParser.RULE_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference" ):
                listener.enterReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference" ):
                listener.exitReference(self)




    def reference(self):

        localctx = UVLPythonParser.ReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_reference)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 387
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,41,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 382
                    self.id_()
                    self.state = 383
                    self.match(UVLPythonParser.T__13) 
                self.state = 389
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

            self.state = 390
            self.id_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID_STRICT(self):
            return self.getToken(UVLPythonParser.ID_STRICT, 0)

        def ID_NOT_STRICT(self):
            return self.getToken(UVLPythonParser.ID_NOT_STRICT, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)




    def id_(self):

        localctx = UVLPythonParser.IdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_id)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 392
            _la = self._input.LA(1)
            if not(_la==60 or _la==61):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOLEAN_KEY(self):
            return self.getToken(UVLPythonParser.BOOLEAN_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_featureType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFeatureType" ):
                listener.enterFeatureType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFeatureType" ):
                listener.exitFeatureType(self)




    def featureType(self):

        localctx = UVLPythonParser.FeatureTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_featureType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 394
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 288230376151941120) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LanguageLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def majorLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.MajorLevelContext,0)


        def minorLevel(self):
            return self.getTypedRuleContext(UVLPythonParser.MinorLevelContext,0)


        def MUL(self):
            return self.getToken(UVLPythonParser.MUL, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_languageLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLanguageLevel" ):
                listener.enterLanguageLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLanguageLevel" ):
                listener.exitLanguageLevel(self)




    def languageLevel(self):

        localctx = UVLPythonParser.LanguageLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_languageLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 396
            self.majorLevel()
            self.state = 402
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 397
                self.match(UVLPythonParser.T__13)
                self.state = 400
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [20, 21, 22, 23]:
                    self.state = 398
                    self.minorLevel()
                    pass
                elif token in [52]:
                    self.state = 399
                    self.match(UVLPythonParser.MUL)
                    pass
                else:
                    raise NoViableAltException(self)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MajorLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOLEAN_KEY(self):
            return self.getToken(UVLPythonParser.BOOLEAN_KEY, 0)

        def getRuleIndex(self):
            return UVLPythonParser.RULE_majorLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMajorLevel" ):
                listener.enterMajorLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMajorLevel" ):
                listener.exitMajorLevel(self)




    def majorLevel(self):

        localctx = UVLPythonParser.MajorLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_majorLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 288230376152498176) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MinorLevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return UVLPythonParser.RULE_minorLevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMinorLevel" ):
                listener.enterMinorLevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMinorLevel" ):
                listener.exitMinorLevel(self)




    def minorLevel(self):

        localctx = UVLPythonParser.MinorLevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_minorLevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 406
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15728640) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[21] = self.constraint_sempred
        self._predicates[23] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def constraint_sempred(self, localctx:ConstraintContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 1)
         

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 1)
         




