PLUGIN_PATHS = [
    'flamapy.metamodels',
]
